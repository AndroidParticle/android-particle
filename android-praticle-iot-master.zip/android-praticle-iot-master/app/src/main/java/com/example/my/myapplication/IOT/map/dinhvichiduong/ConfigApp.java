package com.example.my.myapplication.IOT.map.dinhvichiduong;

/**
 * Created by TM on 5/17/2016.
 */
public class ConfigApp {

    // cua my
    public static final String VITRIGPS = "vitrigps";

    public static String getVITRIGPS() {
        return VITRIGPS;
    }
}
