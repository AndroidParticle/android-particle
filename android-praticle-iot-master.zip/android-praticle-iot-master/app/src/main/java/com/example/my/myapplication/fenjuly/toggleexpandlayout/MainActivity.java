package com.example.my.myapplication.fenjuly.toggleexpandlayout;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.my.librarytoggleexpand.fenjuly.mylibrary.ToggleExpandLayout;

//import com.fenjuly.mylibrary.ToggleExpandLayout;
import com.example.my.myapplication.R;
import com.kyleduo.switchbutton.SwitchButton;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity{// ActionBarActivity {
    Calendar c = Calendar.getInstance();
    TextView second_menu;
    TextView menu;
    ToggleExpandLayout layout, layout2, layout3;
    int hourOfDays, minutes;
    SwitchButton switchButton;


    //alert
    final CharSequence myList[] = { "Tea", "Coffee", "Milk" };
    RelativeLayout rl;

    @Override
    @TargetApi(21)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_toggleexpandlayout);


       // getSupportActionBar().setDisplayShowTitleEnabled(false);

       // layout = (ToggleExpandLayout) findViewById(R.id.toogleLayout);
        layout2 = (ToggleExpandLayout) findViewById(R.id.toogleLayout2);
        layout3 = (ToggleExpandLayout) findViewById(R.id.toogleLayout3);
        switchButton = (SwitchButton) findViewById(R.id.switch_button);
        second_menu = (TextView) findViewById(R.id.second_menutime);
        menu = (TextView) findViewById(R.id.menutime);

/*        layout.setOnToggleTouchListener(new ToggleExpandLayout.OnToggleTouchListener() {
            @Override
            public void onStartOpen(int height, int originalHeight) {
            }

            @Override
            public void onOpen() {
                Log.e("open test layout", "invoked");

                int childCount = layout.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout.getChildAt(i);
                    view.setElevation(dp2px(1));
                }

            }

            @Override
            public void onStartClose(int height, int originalHeight) {
                int childCount = layout.getChildCount();

                Log.e("onStartClose layout", "invoked");

                for (int i = 0; i < childCount; i++) {
                    View view = layout.getChildAt(i);
                    view.setElevation(dp2px(i));
                }
            }

            @Override
            public void onClosed() {
                Log.e("onClosed test layout", "invoked");

            }
        });*/

        switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                  //  layout.open();
                } else {
                   // layout.close();
                }
            }
        });

        SwitchButton switchButton2 = (SwitchButton) findViewById(R.id.switch_button2);

        layout2.setOnToggleTouchListener(new ToggleExpandLayout.OnToggleTouchListener() {
            @Override
            public void onStartOpen(int height, int originalHeight) {
            }

            @Override
            public void onOpen() {
                int childCount = layout2.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout2.getChildAt(i);
                    view.setElevation(dp2px(1));
                }
            }

            @Override
            public void onStartClose(int height, int originalHeight) {
                int childCount = layout2.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout2.getChildAt(i);
                    view.setElevation(dp2px(i));
                }
            }

            @Override
            public void onClosed() {

            }
        });

        switchButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                   layout2.open();
                } else {
                   layout2.close();

                }
            }
        });


        SwitchButton switchButton3 = (SwitchButton) findViewById(R.id.switch_button3);

        layout3.setOnToggleTouchListener(new ToggleExpandLayout.OnToggleTouchListener() {
            @Override
            public void onStartOpen(int height, int originalHeight) {
            }

            @Override
            public void onOpen() {
                int childCount = layout3.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout3.getChildAt(i);
                    view.setElevation(dp2px(1));

                }

            }


            @Override
            public void onStartClose(int height, int originalHeight) {
                int childCount = layout3.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout3.getChildAt(i);
                    view.setElevation(dp2px(i));
                }
            }

            @Override
            public void onClosed() {

            }
        });

        switchButton3.setOnCheckedChangeListener(switchButtonclick);


        TextView modelTextview = (TextView) findViewById(R.id.second_menu);
        modelTextview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               /* switchButton.setChecked(false);
                int childCount = layout.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View view = layout.getChildAt(i);
                    view.setElevation(dp2px(i));
                }*/
                new TimePickerDialog(MainActivity.this, t, c
                        .get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),
                        true).show();
            }
        });


        SwitchButton switchButton4 = (SwitchButton) findViewById(R.id.switch_button4);

        switchButton4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    Log.e("switchbutton open", "invoked");
                   // layout.open();

                    /*new TimePickerDialog(MainActivity.this, t, c
                            .get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),
                            true).show();*/
                } else {
                    Log.e("switchbutton close", "invoked");
                   // layout.close();
                }
            }
        });


        //alert
        rl = (RelativeLayout) findViewById(R.id.myRL);
        final TextView btn = (TextView) findViewById(R.id.second_menu2);

        final AlertDialog.Builder ad = new AlertDialog.Builder(this);
        ad.setTitle("What do you Like ?");
        ad.setSingleChoiceItems(myList, -1, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface arg0, int arg1) {

                Toast.makeText(getApplicationContext(),
                        "You Choose : " + myList[arg1],
                        Toast.LENGTH_LONG).show();

            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                // TODO Auto-generated method stub
                Toast.makeText(getApplicationContext(),
                        "You Have Cancel the Dialog box", Toast.LENGTH_LONG)
                        .show();
            }
        });
        ad.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Toast.makeText(getApplicationContext(),
                        "You Have Ok the Dialog box", Toast.LENGTH_LONG)
                        .show();
            }
        });
        btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                ad.show();
            }
        });

    }

    public void onClicktime(View arg0) {

        new TimePickerDialog(MainActivity.this, t, c
                .get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE),
                true).show();
    }

    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {

        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            // TODO Auto-generated method stub
            //second_menu.setText("Choosen time is :" + hourOfDay + ":" + minute);
            //menu.setText("Choosen time is :" + hourOfDay + ":" + minute);
            Log.e("time", "invoked");
            hourOfDays = hourOfDay;
            minutes = minute;
            update();
        }
    };

    private void update() {
        second_menu.setText("time: " + hourOfDays + ":" + minutes);

        menu.setText("time :" + hourOfDays + ":" + minutes);
/*
        switchButton.setChecked(true);
*/
    }

    CompoundButton.OnCheckedChangeListener switchButtonclick = new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                Log.e("switchbutton open", "invoked");
                layout3.open();

            } else {
                Log.e("switchbutton close", "invoked");
                layout3.close();
            }
        }
    };

    public float dp2px(float dp) {
        final float scale = getResources().getDisplayMetrics().density;
        return dp * scale + 0.5f;
    }
}
