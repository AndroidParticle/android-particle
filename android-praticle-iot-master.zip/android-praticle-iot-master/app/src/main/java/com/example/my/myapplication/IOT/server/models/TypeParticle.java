package com.example.my.myapplication.IOT.server.models;

/**
 * Created by MY on 6/20/2017.
 */
public class TypeParticle {
    private String nameType;
    private String id;
    public TypeParticle(){}

    public String getNameType() {
        return nameType;
    }

    public String getId() {
        return id;
    }
}
