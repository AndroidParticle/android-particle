package com.example.my.myapplication.IOT.server.models;

/**
 * Created by MY on 6/20/2017.
 */
public class ObjectResult {
    private boolean result;
    public  ObjectResult(){}

    public boolean isResult() {
        return result;
    }

    public void setResult(boolean result) {
        this.result = result;
    }
}
