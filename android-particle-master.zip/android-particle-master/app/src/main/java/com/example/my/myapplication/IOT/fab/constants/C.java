package com.example.my.myapplication.IOT.fab.constants;

public interface C {

	/*===================*
	 * Debug and Logging *
	 *===================*/

	String LOG_TAG = "ANDROID_FAB";

}