package com.example.my.myapplication.IOT.map.dinhvichiduong;
public class ConfigApp {

    public static final String VITRIGPS = "vitrigps";

    public static String getVITRIGPS() {
        return VITRIGPS;
    }
}
